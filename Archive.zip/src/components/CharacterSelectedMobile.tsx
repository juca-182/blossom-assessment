import React from "react";
import { ICharacter } from "../types/character";
import { HeartIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartSolidIcon } from '@heroicons/react/24/solid';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import Comments from "./Comments";
import { getStatusColor } from "../utils/helpers";
import { useStore } from "../store/useStore";

const CharacterSelectedMobile: React.FC = () => {
  const { selectedCharacter, setSelectedCharacter, toggleFavorite, isFavorite } = useStore();

  if (!selectedCharacter) {
    return null;
  }

  return (
    <div className="p-4">
      {/* Back Button */}
      <button
        onClick={() => setSelectedCharacter(null)}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors duration-200"
      >
        <ArrowLeftIcon className="w-5 h-5" />
        Back to Characters
      </button>

      {/* Character Details */}
      <div className="text-center">
        {/* Character Avatar */}
        <div className="relative inline-block mb-4">
          <img
            src={selectedCharacter.image}
            alt={selectedCharacter.name}
            className="w-32 h-32 rounded-full object-cover"
          />
          <button
            onClick={() => toggleFavorite(selectedCharacter)}
            className="absolute -bottom-2 -right-2 p-2 bg-white rounded-full shadow-md hover:scale-110 transition-transform duration-200"
          >
            {isFavorite(selectedCharacter.id) ? (
              <HeartSolidIcon className="w-5 h-5 text-green-500" />
            ) : (
              <HeartIcon className="w-5 h-5 text-gray-400 hover:text-red-500" />
            )}
          </button>
        </div>

        {/* Character Name */}
        <h1 className="text-2xl font-bold text-gray-900 mb-6">
          {selectedCharacter.name}
        </h1>

        {/* Character Details */}
        <div className="space-y-4 mb-8">
          <div className="border-b border-gray-200 pb-3">
            <span className="text-sm font-medium text-gray-700">Specie:</span>
            <span className="ml-2 text-gray-900">{selectedCharacter.species}</span>
          </div>

          <div className="border-b border-gray-200 pb-3">
            <span className="text-sm font-medium text-gray-700">Status:</span>
            <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedCharacter.status)}`}>
              {selectedCharacter.status}
            </span>
          </div>

          {selectedCharacter.type && (
            <div className="border-b border-gray-200 pb-3">
              <span className="text-sm font-medium text-gray-700">Occupation:</span>
              <span className="ml-2 text-gray-900">{selectedCharacter.type}</span>
            </div>
          )}
        </div>

        {/* Comments Section */}
        <Comments characterId={selectedCharacter.id} />
      </div>
    </div>
  );
};

export default CharacterSelectedMobile; 