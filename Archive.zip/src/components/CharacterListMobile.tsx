import React from "react";
import { useQuery } from '@apollo/client';
import { GET_CHARACTERS } from '../services/queries';
import { ICharacter } from "../types/character";
import { HeartIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartSolidIcon } from '@heroicons/react/24/solid';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import Comments from "./Comments";
import SearchAndFilter from "./SearchAndFilter";
import { getStatusColor } from "../utils/helpers";
import { useStore } from "../store/useStore";
import { filterCharacters, sortCharacters } from "../utils/helpers";
import CharacterSelectedMobile from "./CharacterSelectedMobile";


const CharacterListMobile: React.FC<{
  }> = () => {
  const { 
    favorites,
    selectedCharacter, 
    setSelectedCharacter, 
    filters, 
    setFilters, 
    sortBy, 
    sortOrder, 
    setSort, 
    toggleFavorite, 
    isFavorite,
    currentPage,
    setCurrentPage
  } = useStore();

  // GraphQL query for characters
  const { loading, error, data, fetchMore } = useQuery(GET_CHARACTERS, {
    variables: {
      page: currentPage,
      filter: {
        name: filters.name || undefined,
        status: filters.status || undefined,
        species: filters.species || undefined,
        gender: filters.gender || undefined,
      },
    },
    notifyOnNetworkStatusChange: true,
  });

  // Combine API characters with favorites
  const allCharacters = data?.characters?.results || [];
  const combinedCharacters = [...allCharacters, ...favorites.filter(fav =>
    !allCharacters.some((char: ICharacter) => char.id === fav.id)
  )];

  // Apply client-side filtering and sorting
  const filteredCharacters = filterCharacters(combinedCharacters, filters);
  const sortedCharacters = sortCharacters(filteredCharacters, sortBy, sortOrder);

  // Separate starred and regular characters
  const starredCharacters = sortedCharacters.filter(char => isFavorite(char.id));
  const regularCharacters = sortedCharacters.filter(char => !isFavorite(char.id));

  const handleFilterChange = (newFilters: any) => {
    setFilters(newFilters);
    setCurrentPage(1);
  };

  const handleSortChange = (newSortBy: string, newSortOrder: 'asc' | 'desc') => {
    setSort(newSortBy, newSortOrder);
  };

  const handleCharacterClick = (character: ICharacter) => {
    setSelectedCharacter(character);
  };
    return (
      <div className="block lg:hidden">
        {selectedCharacter ? (
         <CharacterSelectedMobile />
        ) : (
          // Mobile List View
          <div className="p-4">
            {/* Header */}
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Rick and Morty list</h1>
            </div>

            {/* Search and Filter */}
            <div className="mb-6">
              <SearchAndFilter
                onFilterChange={handleFilterChange}
                onSortChange={handleSortChange}
                totalResults={sortedCharacters.length}
              />
            </div>

            {/* Character Lists */}
            <div className="space-y-6">
              {/* Starred Characters Section */}
              {starredCharacters.length > 0 && (
                <div>
                  <h2 className="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">
                    Starred Characters ({starredCharacters.length})
                  </h2>
                  <div className="space-y-2">
                    {starredCharacters.map((character) => (
                      <div
                        key={character.id}
                        className="flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors duration-200 hover:bg-gray-50"
                        onClick={() => handleCharacterClick(character)}
                      >
                        <img
                          src={character.image}
                          alt={character.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-gray-900 truncate">{character.name}</h3>
                          <p className="text-sm text-gray-600">{character.species}</p>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(character);
                          }}
                          className="p-1"
                        >
                          <HeartSolidIcon className="w-5 h-5 text-green-500" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Regular Characters Section */}
              <div>
                <h2 className="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">
                  Characters ({regularCharacters.length})
                </h2>
                <div className="space-y-2">
                  {regularCharacters.map((character) => (
                    <div
                      key={character.id}
                      className="flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors duration-200 hover:bg-gray-50"
                      onClick={() => handleCharacterClick(character)}
                    >
                      <img
                        src={character.image}
                        alt={character.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate">{character.name}</h3>
                        <p className="text-sm text-gray-600">{character.species}</p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(character);
                        }}
                        className="p-1"
                      >
                        <HeartIcon className="w-5 h-5 text-gray-400 hover:text-red-500" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Loading State */}
            {loading && (
              <div className="flex justify-center items-center py-4">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary-600"></div>
              </div>
            )}

          </div>
        )}
      </div>
    );
  };



export default CharacterListMobile;