import React from "react";

const CharacterNonSelected: React.FC = () => {
  return (
    <div className="flex-1 p-8 flex items-center justify-center">
      <div className="text-center text-gray-500">
        <h2 className="text-xl font-semibold mb-2">Select a Character</h2>
        <p>Click on a character from the list to view their details</p>
      </div>
    </div>
  );
};

export default CharacterNonSelected;
