import React from "react";
import { createBrowserRouter } from "react-router-dom";
import CharacterList from "./pages/CharacterList";
import CharacterSelectedDesktop from "./components/CharacterSelectedDesktop";
import CharacterDetail from "./pages/CharacterDetail";



    const routes = createBrowserRouter([
        {
            path: "/",
            Component: CharacterList,
            children: [
                {
                    path: ":id",
                    Component: CharacterSelectedDesktop
                }
            ]
        }
    ])

    export default routes;